import 'home_model.dart';
final List<home_property> datalist=[
  home_property(
      name: 'Smart Office',
      place: 'Noida',
      imageUrl: [
        'https://img.freepik.com/premium-photo/blank-photo-frame-mockup-adorns-working-room-s-interior-social-media-post-size_892776-14659.jpg?w=740',
        'https://img.freepik.com/premium-photo/blank-photo-frame-mockup-adorns-working-room-s-interior-social-media-post-size_892776-14659.jpg?w=740',

     ],
      price: '\$100/month',
      details: 'Our semi-furnished office spaces provide the perfect blend of flexibility and functionality. Each space includes essential furniture such as desks, chairs, and storage units, allowing you to customize the rest according to your needs. High-speed internet and advanced electricity systems are included to ensure smooth operations. You ll also benefit from access to a well-stocked pantry and professional meeting rooms. Utilities and maintenance are taken care of, offering a hassle-free experience. With this setup, you can easily create a workspace that fits your unique business requirements while enjoying the convenience of essential amenities.',
      carpark: 'Available',
    location: 'Noida',
    cabins: '3',
    meetingrooms: 'Conference Available',
    lift: 'Available',
    typeoffice: 'Ready to move',
    lookingfor: 'Rent Only',
    officecapacity: 'Seats-32',
    furnishing: 'Including all',
    sqft: '₹ 4500',
    washrooms: '4',
    budget: '45000',
    floor: 'Other floor',

  ),
  home_property(
      name: 'Sweet Officee',
      place: 'Noida',
      imageUrl: [
        'https://img.freepik.com/premium-photo/office-room-logo-mockup-poster-frame_919955-17519.jpg?w=740',
        'https://img.freepik.com/premium-photo/office-room-logo-mockup-poster-frame_919955-17519.jpg?w=740',

    ],
    price: '\$100/month',
      details: 'A property description is an overview that provides detailed information about key features, spaces, amenities and conditions of a property. It appears as the written portion of a real estate listing and may be called a property description” or a “real estate description” as both terms refer to the same section of a property listing.',
    carpark: 'Available',
    location: 'Noida',
    cabins: '3',
    meetingrooms: 'Conference Available',
    lift: 'Available',
    typeoffice: 'Ready to move',
    lookingfor: 'Rent Only',
    officecapacity: 'Seats-32',
    furnishing: 'Including all',
    sqft: '4500',
    washrooms: '4',
    budget: '45000',
    floor: 'Other floor',

  ),
  home_property(
      name: 'Best Office',
      place: 'Noida',
      imageUrl:[
        'https://img.freepik.com/premium-photo/5-splitscreen-office-home-desks-modernist-clean-lines-vector-art-efficient-hybrid-work-model_486608-676.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',
        'https://img.freepik.com/premium-photo/5-splitscreen-office-home-desks-modernist-clean-lines-vector-art-efficient-hybrid-work-model_486608-676.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',

    ],
    price: '\$100/month',
      details: 'Our semi-furnished office spaces provide the perfect blend of flexibility and functionality. Each space includes essential furniture such as desks, chairs, and storage units, allowing you to customize the rest according to your needs. High-speed internet and advanced electricity systems are included to ensure smooth operations. You will also benefit from access to a well-stocked pantry and professional meeting rooms. Utilities and maintenance are taken care of, offering a hassle-free experience. With this setup, you can easily create a workspace that fits your unique business requirements while enjoying the convenience of essential amenities.',
    carpark: 'Available',
    location: 'Noida',
    cabins: '3',
    meetingrooms: 'Conference Available',
    lift: 'Available',
    typeoffice: 'Ready to move',
    lookingfor: 'Rent Only',
    officecapacity: 'Seats-32',
    furnishing: 'Including all',
    sqft: '4500',
    washrooms: '4',
    budget: '45000',
    floor: 'Other floor',

  ),
  home_property(
      name: 'Best Office',
      place: 'Noida',
      imageUrl: [
        'https://img.freepik.com/premium-photo/empty-hyper-modern-music-studio-with-big-speakers_916191-218241.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',
        'https://img.freepik.com/premium-photo/empty-hyper-modern-music-studio-with-big-speakers_916191-218241.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',

    ],
    price: '\$100/month',
      details: 'Our semi-furnished office spaces provide the perfect blend of flexibility and functionality. Each space includes essential furniture such as desks, chairs, and storage units, allowing you to customize the rest according to your needs. High-speed internet and advanced electricity systems are included to ensure smooth operations. You will also benefit from access to a well-stocked pantry and professional meeting rooms. Utilities and maintenance are taken care of, offering a hassle-free experience. With this setup, you can easily create a workspace that fits your unique business requirements while enjoying the convenience of essential amenities.',
    carpark: 'Available',
    location: 'Noida',
    cabins: '3',
    meetingrooms: 'Conference Available',
    lift: 'Available',
    typeoffice: 'Ready to move',
    lookingfor: 'Rent Only',
    officecapacity: 'Seats-32',
    furnishing: 'Including all',
    sqft: '4500',
    washrooms: '4',
    budget: '45000',
    floor: 'Other floor',


  ),
  home_property(
      name: 'Offices',
      place: 'Delhi',
      imageUrl: [
        'https://img.freepik.com/premium-photo/modern-office-space-with-minimalist-design-promoting-productivity_1294860-32230.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',
        'https://img.freepik.com/premium-photo/modern-office-space-with-minimalist-design-promoting-productivity_1294860-32230.jpg?ga=GA1.1.435796893.1694598652&semt=ais_hybrid',

    ],
    price: '\$110/month',
    details: 'Our semi-furnished office spaces provide the perfect blend of flexibility and functionality. Each space includes essential furniture such as desks, chairs, and storage units, allowing you to customize the rest according to your needs. High-speed internet and advanced electricity systems are included to ensure smooth operations. You will also benefit from access to a well-stocked pantry and professional meeting rooms. Utilities and maintenance are taken care of, offering a hassle-free experience. With this setup, you can easily create a workspace that fits your unique business requirements while enjoying the convenience of essential amenities.',
    carpark: 'Available',
    location: 'Noida',
    cabins: '3',
    meetingrooms: 'Conference Available',
    lift: 'Available',
    typeoffice: 'Ready to move',
    lookingfor: 'Rent Only',
    officecapacity: 'Seats-32',
    furnishing: 'Including all',
    sqft: '4500',
    washrooms: '4',
    budget: '45000',
    floor: 'Other floor',


  ),


];