class UserModel{
  String name;
  String branch;
  String collage;

  UserModel(this.name, this.branch, this.collage);
  
}

List userList=[
  UserModel('Rohit', 'Android', 'collage'),
  UserModel('Sumit', 'Flutter', 'collage'),
  UserModel('Ashish', 'TL', 'collage'),
  UserModel('Ritu', 'branch', 'collage'),
  UserModel('Porush', 'branch', 'collage'),
];