class Office_property {
  final String heading;
  final String text;
  final List<String> imageUrl;
  final String workstation;
  final String cabin;
  final String pentry;
  final String Maintenance;
  final String metrodistance;
  final String containt;

  Office_property({

    required this.heading,
    required this.text,
    required this.imageUrl,
    required this.workstation,
    required this.cabin,
    required this.pentry,
    required this.Maintenance,
    required this.metrodistance,
    required this.containt,

});
}