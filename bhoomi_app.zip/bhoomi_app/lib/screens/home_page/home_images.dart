String building="assets/icons/building.png";
String newimage="assets/logoicon/newlogo.png";